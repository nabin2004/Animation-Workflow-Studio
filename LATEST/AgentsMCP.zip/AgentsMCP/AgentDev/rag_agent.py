# rag_agent.py
from google_adk import Agent
from rag_tool import RAGTool

# Initialize your RAG search tool
rag_tool = RAGTool()

# Minimal agent
class ManimAgent(Agent):
    def plan(self, query: str):
        # Step 1: RAG search
        retrieved_chunks = rag_tool.search(query, top_k=5)
        # Step 2: Summarize or extract instructions
        code_snippets = "\n\n".join([c["code"] for c in retrieved_chunks])
        return f"Use these code snippets for: {query}\n\n{code_snippets}"

# Initialize agent
agent = ManimAgent()
