# chat.py
from rag_agent import agent

while True:
    query = input("Enter your Manim query: ")
    if query.lower() in ("quit", "exit"):
        break
    response = agent.plan(query)
    print("\n--- Response ---\n")
    print(response[:2000])  # truncate for readability
    print("\n----------------\n")
