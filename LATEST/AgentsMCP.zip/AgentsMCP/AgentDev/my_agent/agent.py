# agent.py
from google.adk.agents.llm_agent import Agent
from rag_tool import RAGTool  # your RAG wrapper from earlier
import torch

# Initialize the RAG tool (embedding search over Manim codebase)
rag_tool = RAGTool()

# Define a helper function for the agent to call the RAG tool
def retrieve_manim_code(query: str, top_k: int = 5):
    results = rag_tool.search(query, top_k=top_k)
    code_snippets = "\n\n".join([f"# File: {c['file']} | {c['type']} {c['name']}\n{c['code']}" 
                                 for c in results])
    return code_snippets

# Initialize the root agent
root_agent = Agent(
    model="gemini-2.5-flash",
    name="root_agent",
    description="Code-only Manim assistant that returns executable Python code.",
    instruction=(
        "You are a code-only assistant specialized in the Manim library.\n"
        "Given a user query, always produce a single valid, executable Python code block.\n"
        "Use the retrieve_manim_code() tool to gather references from the Manim codebase.\n"
        "Do not include greetings, explanations, or markdown outside the code block.\n"
        "Do not include ```python or ``` markers — only return raw Python code ready to compile.\n"
        "If multiple solutions exist, return the cleanest, minimal working example.\n"
        ),
    tools=[retrieve_manim_code],
    # tools={
    #     "rag_search": retrieve_manim_code
    # },
    # tools={
    #     "rag_search": retrieve_manim_code
    # }

)
