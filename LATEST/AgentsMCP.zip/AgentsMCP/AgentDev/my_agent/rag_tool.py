# rag_tool.py
import numpy as np
import json
import torch
from sentence_transformers import util

class RAGTool:
    def __init__(self, embedded_file="manim_code_embedded.json"):
        with open(embedded_file, "r", encoding="utf-8") as f:
            self.chunks = json.load(f)
        self.embeddings = torch.tensor([c["embedding"] for c in self.chunks], dtype=torch.float32)

    def search(self, query, top_k=5):
        # Compute query embedding
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer("all-MiniLM-L6-v2")  # lightweight for demo
        query_emb = torch.tensor(model.encode(query), dtype=torch.float32)
        # Cosine similarity
        scores = util.cos_sim(query_emb, self.embeddings)[0]
        top_idx = torch.topk(scores, top_k).indices.tolist()
        results = [self.chunks[i] for i in top_idx]
        return results
